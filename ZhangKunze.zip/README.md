This is Zhang Kunze's resource pack.

This pack used Faithful 64x, but now not use.

And that's not good.

此资源包采用双许可证模式：您可以在 GPL-3.0-or-later 或 ZRPL（ZKZLLPPAM Resource Pack License）-1.0-or-later之间选择其一作为您的许可证。

根目录下的 “LICENSE_CCO.md” 是因为本 Resource Pack 使用了一个 CCO 许可证的 Resource Pack，出于道德，所以添加了，但是这并不为本仓库使用，本仓库也不提供 CCO v1 作为选择。

Using Marlowww+ Resource pack

Using Natural Mystic Shaders Resource pack

Using Bedrock Dark Mode

Using Dark Mode Bedrock