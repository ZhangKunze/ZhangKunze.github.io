SPDX-License-Identifier: GPL-3.0-or-later AND ZRPL-1.0-or-later
ZKZLLPPAM Resource Pack License version 1.0

© Copyright 2026 Zhang Kunze

This license governs the use, modification, and distribution of this resource pack.

0. Definitions
{
"Resource Pack" refers to the official interface-compatible packages used to modify Minecraft Java Edition and Bedrock Edition. Java Edition resource packs typically have the extension .zip, while Bedrock Edition resource packs typically have the extension .mcpack. This license applies to both types.

"Distribution" is defined as per the GNU General Public License version 3.
}
1. You are permitted to freely modify this pack. However, if you distribute your modified version, you must retain the original author's credit notice, except in the case described in Section 3.

2. If you modify and redistribute this pack, your distribution must be licensed under the same terms as this license, and you must allow others to use any resources contained within your modified pack.

3. For limited private distribution—such as sharing with friends, classmates, or within a company—none of the requirements of this license apply. However, once the pack is uploaded to public platforms such as CurseForge, this license becomes fully effective.

4. If this pack contains assets governed by other licenses, those assets must be handled in accordance with their respective license terms. This license is designed to be compatible with other licenses whenever possible.

5. In the event of a conflict between this license and another license governing assets used within this pack, the terms of the other license shall prevail.

6. If the other license referenced in Section 5 contains a similar "precedence" clause (e.g., stating that its terms are superseded by other licenses), then the definitions set forth in this pack shall take precedence. Should this pack contain no such definition, an additional license—such as MIT or Apache 2.0—shall be applied to cover any unresolved gaps.

7. Disclaimer of Warranty and Limitation of Liability

THE RESOURCE PACK IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT.

YOU ASSUME ALL RISKS ASSOCIATED WITH THE USE OF THIS RESOURCE PACK. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE THE RESOURCE PACK, INCLUDING BUT NOT LIMITED TO: SYSTEM CRASHES, BLUE SCREEN ERRORS, DATA LOSS, HARDWARE OR SOFTWARE MALFUNCTIONS, OR ANY OTHER DAMAGES.

If you encounter any issues while using this resource pack, you are welcome to contact the author for assistance or to provide feedback—constructively. The author is willing to help resolve problems but does not accept liability or blame arising from their use.

8. Distinctiveness Requirement

When distributing any modified version of this Resource Pack, you must ensure that users can clearly understand that the version is not the original work of the original author.

Specifically:

a) The project name must be clearly distinguishable from the original project name, with at least 50% of the content being different. You may not merely add a prefix or suffix (e.g., "XX Edition", "-modified", "+optimized") to imply or mislead association with the original work. When calculating name similarity, generic descriptive terms (such as 'resource pack', 'texture pack', '材质包', '资源包', etc.) shall not be included in the similarity calculation, to ensure that the distinctiveness requirement applies to the core name portion.

b) You must include the following statement prominently and conspicuously on the distribution page, in the description, or within the accompanying documentation:

This clause references and draws upon the relevant provisions regarding distinctiveness in the Faithful License v3.

By using this pack, you agree to the terms of this license.
